# Справочник ЛС

Веб-приложение для работы со справочником лекарственных средств.  
Данные хранятся в [Supabase](https://supabase.com). Деплой — статика (без сборки).

---

## Структура проекта

```
drug-handbook/
├── index.html          ← HTML-скелет (без инлайн CSS и JS)
├── favicon.png         ← иконка (нужно добавить)
│
├── css/
│   └── styles.css      ← все стили (темы, компоненты, адаптив)
│
└── js/
    ├── config.js       ← Supabase URL/KEY, LINK_TYPES, ADMIN_HASH
    ├── state.js        ← глобальные переменные (drugs, isAdmin, ...)
    ├── db.js           ← все функции работы с базой данных
    ├── theme.js        ← переключение светлой/тёмной темы
    ├── ui.js           ← toast, пароль, lockState, esc/nl2br, info-modal
    ├── search.js       ← поиск, дропдаун, добавление/удаление ЛС
    ├── catalog.js      ← каталог препаратов (боковая панель)
    ├── drug.js         ← страница препарата, левый nav, редактор
    ├── calculators.js  ← калькуляторы (BSA, Шварц, КК, Кэлверт, Смитс)
    ├── topics.js       ← шаблоны
    └── main.js         ← init() + глобальные event listeners
```

> **Порядок загрузки скриптов фиксирован** в `index.html` — не переставляй теги `<script>`.  
> Все файлы используют общий глобальный скоуп, переменные из `state.js` видны везде.

---

## Быстрый старт (локально)

Открыть напрямую через `index.html` **не получится** из-за CORS при загрузке JS-файлов в Chrome.  
Нужен любой локальный HTTP-сервер:

```bash
# Python 3
python3 -m http.server 8080

# Node.js (npx, без установки)
npx serve .

# VS Code: расширение Live Server (кнопка "Go Live" в статус-баре)
```

Затем открыть: `http://localhost:8080`

---

## Деплой на GitHub Pages

### 1. Создать репозиторий

```bash
git init
git add .
git commit -m "feat: initial commit — split monolith into files"
```

Создай репозиторий на GitHub (например `drug-handbook`) и:

```bash
git remote add origin https://github.com/ВАШ_ЛОГИН/drug-handbook.git
git branch -M main
git push -u origin main
```

### 2. Включить GitHub Pages

1. Репозиторий → **Settings** → **Pages**
2. Source: `Deploy from a branch`
3. Branch: `main` / `/ (root)`
4. Нажать **Save**

Через ~1 минуту сайт будет доступен по адресу:  
`https://ВАШ_ЛОГИН.github.io/drug-handbook/`

### 3. Добавить favicon.png

Положи файл `favicon.png` в корень проекта рядом с `index.html`.

---

## Смена пароля администратора

Пароль хранится как SHA-256 хеш в `js/config.js` (переменная `ADMIN_HASH`).

Чтобы сменить пароль:
1. Открой консоль браузера (F12 → Console)
2. Выполни:
```js
crypto.subtle.digest('SHA-256', new TextEncoder().encode('НовыйПароль'))
  .then(b => console.log([...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('')))
```
3. Скопируй хеш и замени значение `ADMIN_HASH` в `js/config.js`

---

## Добавить новый калькулятор

1. **HTML** — добавь модал-оверлей в `index.html` по образцу уже существующих
2. **JS** — добавь ID в массив `CALC_IDS` и функцию расчёта в `js/calculators.js`
3. **Список** — добавь `<div class="catalog-item">` в `#calc-overlay` в `index.html`

---

## Supabase

Проект использует две таблицы:

| Таблица | Поля       | Описание        |
|---------|------------|-----------------|
| `drugs` | `id`, `data` | Лекарственные средства |
| `topics`| `id`, `data` | Шаблоны         |

Настройки подключения находятся в `js/config.js`.
